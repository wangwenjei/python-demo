selenium
opencv-contrib-python
pandas
image
pytesseract
pandas

https://blog.csdn.net/weixin_41635750/article/details/117536676
电脑需装chrome的webdrive吗

https://cmegsb.cma.org.cn/national_project/listBaseProjectGongbu.jsp
爬取历年数据




pip install beautifulsoup4
Image

安装OCR工具
Healife:~ shaun$ brew install tesseract
Healife:~ shaun$ tesseract -v
tesseract 5.1.0
 leptonica-1.82.0