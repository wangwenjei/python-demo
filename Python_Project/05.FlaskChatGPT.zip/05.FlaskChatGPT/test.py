import json
import hashlib


def encry_local_prv_key(local_prv_key):
    pk_str = json.dumps(local_prv_key)
    m = hashlib.sha1()
    m.update(pk_str)
    msg = m.hexdigest()
    print(msg)
    return msg


def encry_local_prv_key1(local_prv_key, charset="utf-8"):
    pk_str = json.dumps(local_prv_key).encode(charset)

    m = hashlib.sha1()
    m.update(pk_str)
    msg = m.hexdigest()
    print(msg)
    return msg




local_prv_key='NYfdT7lY2E uDZwyqNqZwoClN3 2qtLhs4k2wRKJ7ICo5an7JXu236Wlyn37ZnyvMvycomWPGSdzPF6YUkAiyA=='
# encry_local_prv_key1(local_prv_key=local_prv_key)

msg=json.dumps(local_prv_key).encode('utf-8')
a = hashlib.sha1()
print(a)
a.update(msg)
print(a.hexdigest())