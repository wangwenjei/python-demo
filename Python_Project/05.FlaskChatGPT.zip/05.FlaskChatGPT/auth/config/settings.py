CORP_ID = "ww2604db4b203f3cb4"
SECRET = "oG7F9Je1TGwbqC6nf2hO7uBeVNgr9DmWl4oaVn0GJ5Y"
Verify_URL = 'http://wechatai.it97.top/Wx/dataVerify'
Verify_Token = '9XSNKGvEH'
Verify_EncodingAESKey = 'Ot9lC94cFvvp92lj9Fm6r1QLlKTbNJjU85Dg77DhO69'
ChatGPTApiKey = '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'
